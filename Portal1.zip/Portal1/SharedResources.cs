﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PT.UI
{
    /// <summary>
    /// Dummy Class for shared resources
    /// </summary>
    
    public class SharedResources
    {
    }
}
